<?php
session_start();
if (!isset($_SESSION['login'])) {
    header("Location: login.php");
    exit;
}
?>

<html>
    <head>
        <title>Tambah Registrasi</title>
        <link rel="stylesheet" href="css/style.css">
    </head>

    <body>
        <h1>Tambah Registrasi</h1>
        <form method="POST" action="prosestambahregistrasi.php">
            <label for="nama">Nama:</label>
            <input type="text" name="nama" required>

            <label for="alamat">Alamat:</label>
            <textarea name="alamat" required></textarea>

            <label for="jenis_kelamin">Jenis Kelamin:</label>
            <select name="jenis_kelamin" required>
                <option value="L">Laki-laki</option>
                <option value="P">Perempuan</option>
            </select>

            <label for="tlp">Telepon:</label>
            <input type="tel" name="tlp" required>

            <div class="button-container">
                <button type="submit" name="tambah">Tambah</button>
                <button type="button" name="batal" onclick="window.history.back();">Batal</button>
            </div>
        </form>
    </body>
</html>
