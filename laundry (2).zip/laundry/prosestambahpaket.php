<?php
session_start();
if (!isset($_SESSION['login'])) {
    header("Location: login.php");
    exit;
}

include 'koneksi.php';

if (isset($_POST['tambah'])) {
    $id_outlet = mysqli_real_escape_string($koneksi, $_POST['id_outlet']);
    $jenis = mysqli_real_escape_string($koneksi, $_POST['jenis']);
    $nama_paket = mysqli_real_escape_string($koneksi, $_POST['nama_paket']);
    $harga = mysqli_real_escape_string($koneksi, $_POST['harga']);

    $query = "SELECT MAX(id) as max_id FROM tb_paket";
    $result = mysqli_query($koneksi, $query);
    $data = mysqli_fetch_assoc($result);
    $new_id = $data['max_id'] + 1;

    $query_insert = "INSERT INTO tb_paket (id, id_outlet, jenis, nama_paket, harga) VALUES ('$new_id', '$id_outlet', '$jenis', '$nama_paket', '$harga')";
    
    if (mysqli_query($koneksi, $query_insert)) {
        header("Location: paket.php?status=success");
    } else {
        header("Location: tambahpaket.php?status=error");
    }
}
?>
