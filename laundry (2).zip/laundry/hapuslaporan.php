<?php
session_start();
if (!isset($_SESSION['login'])) {
    header("Location: login.php");
    exit;
}

include 'koneksi.php';

$id = $_GET['id'];
$query = "DELETE FROM tb_detail_transaksi WHERE id = '$id'";
$result = mysqli_query($koneksi, $query);

if ($result) {
    echo "<script>alert('Data laporan berhasil dihapus!');</script>";
    header("Location: laporan.php");
} else {
    echo "<script>alert('Gagal hapus data laporan!');</script>";
}
?>