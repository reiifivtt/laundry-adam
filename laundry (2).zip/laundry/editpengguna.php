<?php
session_start();
if (!isset($_SESSION['login'])) {
    header("Location: login.php");
    exit;
}

include 'koneksi.php';

$id = $_GET['id'];
$query = "SELECT * FROM tb_user WHERE id = '$id'";
$result = mysqli_query($koneksi, $query);
$data = mysqli_fetch_assoc($result);

if (isset($_POST['edit'])) {
    $nama = mysqli_real_escape_string($koneksi, $_POST['nama']);
    $username = mysqli_real_escape_string($koneksi, $_POST['username']);
    $password = mysqli_real_escape_string($koneksi, $_POST['password']);
    $id_outlet = mysqli_real_escape_string($koneksi, $_POST['id_outlet']);
    $role = mysqli_real_escape_string($koneksi, $_POST['role']);

    $query = "UPDATE tb_user SET nama = '$nama', username = '$username', password = '$password', id_outlet = '$id_outlet', role = '$role' WHERE id = '$id'";
    $result = mysqli_query($koneksi, $query);

    if ($result) {
        echo "<script>alert('Data pengguna berhasil diupdate!');</script>";
        header("Location: pengguna.php");
    } else {
        echo "<script>alert('Gagal update data pengguna!');</script>";
    }
}
?>

<html>
    <head>
        <title>Edit Pengguna</title>
        <link rel="stylesheet" href="css/style.css">
    </head>

    <body>
        <h1>Edit Pengguna</h1>
        <form method="POST" action="" class="tambah-registrasi-form">
            <label for="nama">Nama:</label>
            <input type="text" name="nama" value="<?php echo $data['nama']; ?>" required>

            <label for="username">Username:</label>
            <input type="text" name="username" value="<?php echo $data['username']; ?>" required>

            <label for="password">Password:</label>
            <input type="password" name="password" value="<?php echo $data['password']; ?>" required>

            <label for="id_outlet">ID Outlet:</label>
            <select name="id_outlet" required>
                <?php
                include 'koneksi.php';
                $query = "SELECT id, nama FROM tb_outlet";
                $result = mysqli_query($koneksi, $query);
                while ($outlet = mysqli_fetch_assoc($result)) {
                    // Menampilkan ID dan nama outlet dalam format "ID | Nama"
                    $selected = ($outlet['id'] == $data['id_outlet']) ? 'selected' : '';
                    echo "<option value='".$outlet['id']."' $selected>".$outlet['id']." | ".$outlet['nama']."</option>";
                }
                ?>
            </select>

            <label for="role">Role:</label>
            <select name="role" required>
                <option value="">Pilih Role</option>
                <option value="admin" <?php echo ($data['role'] == 'admin') ? 'selected' : ''; ?>>Admin</option>
                <option value="kasir" <?php echo ($data['role'] == 'kasir') ? 'selected' : ''; ?>>Kasir</option>
                <option value="owner" <?php echo ($data['role'] == 'owner') ? 'selected' : ''; ?>>Owner</option>
            </select>

            <div class="button-container">
                <button type="submit" name="edit">Edit</button>
                <button type="button" name="batal" onclick="window.history.back();">Batal</button>
            </div>
        </form>
    </body>
</html>