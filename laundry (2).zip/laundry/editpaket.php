<?php
session_start();
if (!isset($_SESSION['login'])) {
    header("Location: login.php");
    exit;
}

include 'koneksi.php';

$id = $_GET['id'];
$query = "SELECT * FROM tb_paket WHERE id = '$id'";
$result = mysqli_query($koneksi, $query);
$data = mysqli_fetch_assoc($result);

if (isset($_POST['edit'])) {
    $id_outlet = mysqli_real_escape_string($koneksi, $_POST['id_outlet']);
    $jenis = mysqli_real_escape_string($koneksi, $_POST['jenis']);
    $nama_paket = mysqli_real_escape_string($koneksi, $_POST['nama_paket']);
    $harga = mysqli_real_escape_string($koneksi, $_POST['harga']);

    $query = "UPDATE tb_paket SET id_outlet = '$id_outlet', jenis = '$jenis', nama_paket = '$nama_paket', harga = '$harga' WHERE id = '$id'";
    $result = mysqli_query($koneksi, $query);

    if ($result) {
        echo "<script>alert('Data paket berhasil diupdate!');</script>";
        header("Location: paket.php");
    } else {
        echo "<script>alert('Gagal update data paket!');</script>";
    }
}
?>

<html>
    <head>
        <title>Edit Paket</title>
        <link rel="stylesheet" href="css/style.css">
    </head>

    <body>
        <h1>Edit Paket</h1>
        <form method="POST" action="" class="tambah-registrasi-form">
            <label for="id_outlet">ID Outlet:</label>
            <select name="id_outlet" required>
                <?php
                include 'koneksi.php';
                $query = "SELECT id, nama FROM tb_outlet";
                $result = mysqli_query($koneksi, $query);
                while ($outlet = mysqli_fetch_assoc($result)) {
                    // Menampilkan ID dan nama outlet dalam format "ID | Nama"
                    $selected = ($outlet['id'] == $data['id_outlet']) ? 'selected' : '';
                    echo "<option value='".$outlet['id']."' $selected>".$outlet['id']." | ".$outlet['nama']."</option>";
                }
                ?>
            </select>

            <label for="jenis">Jenis:</label>
            <select name="jenis" required>
                <option value="kiloan" <?php echo $data['jenis'] == 'kiloan' ? 'selected' : ''; ?>>Kiloan</option>
                <option value="selimut" <?php echo $data['jenis'] == 'selimut' ? 'selected' : ''; ?>>Selimut</option>
                <option value="bed_cover" <?php echo $data['jenis'] == 'bed_cover' ? 'selected' : ''; ?>>Bed Cover</option>
                <option value="kaos" <?php echo $data['jenis'] == 'kaos' ? 'selected' : ''; ?>>Kaos</option>
                <option value="lain" <?php echo $data['jenis'] == 'lain' ? 'selected' : ''; ?>>Lain</option>
            </select>

            <label for="nama_paket">Nama Paket:</label>
            <input type="text" name="nama_paket" value="<?php echo $data['nama_paket']; ?>" required>

            <label for="harga">Harga:</label>
            <input type="number" name="harga" value="<?php echo $data['harga']; ?>" required>

            <div class="button-container">
                <button type="submit" name="edit">Edit</button>
                <button type="button" name="batal" onclick="window.history.back();">Batal</button>
            </div>
        </form>
    </body>
</html>