<?php
session_start();
if (!isset($_SESSION['login'])) {
    header("Location: login.php");
    exit;
}
?>

<html>
    <head>
        <title>Tambah Laporan</title>
        <link rel="stylesheet" href="css/style.css">
    </head>

    <body>
        <h1>Tambah Laporan</h1>
        <form method="POST" action="prosestambahlaporan.php">
        <label for="id_transaksi">ID Transaksi:</label>
            <select name="id_transaksi" required>
                <?php
                include 'koneksi.php';
                $query = "SELECT id, kode_invoice FROM tb_transaksi";
                $result = mysqli_query($koneksi, $query);
                while ($transaksi = mysqli_fetch_assoc($result)) {
                    echo "<option value='".$transaksi['id']."'>".$transaksi['id']." | ".$transaksi['kode_invoice']."</option>";
                }
                ?>
            </select>

            <label for="id_paket">ID Paket:</label>
            <select name="id_paket" required>
                <?php
                include 'koneksi.php';
                $query = "SELECT id, nama_paket FROM tb_paket";
                $result = mysqli_query($koneksi, $query);
                while ($paket = mysqli_fetch_assoc($result)) {
                    echo "<option value='".$paket['id']."'>".$paket['id']." | ".$paket['nama_paket']."</option>";
                }
                ?>
            </select>

            <label for="qty">QTY:</label>
            <input type="number" name="qty" required>

            <label for="keterangan">Keterangan:</label>
            <textarea name="keterangan" required></textarea>

            <div class="button-container">
                <button type="submit" name="tambah">Tambah</button>
                <button type="button" name="batal" onclick="window.history.back();">Batal</button>
            </div>
        </form>
    </body>
</html>
