<?php
session_start();
if (!isset($_SESSION['login'])) {
    header("Location: login.php");
    exit;
}
?>

<html>
    <head>
        <title>Laporan</title>
        <link rel="stylesheet" href="css/table.css">
    </head>
    <body>
        <h1>Laporan</h1>
        <table>
            <tr>
                <th>ID</th>
                <th>ID Transaksi</th>
                <th>ID Paket</th>
                <th>QTY</th>
                <th>Keterangan</th>
                <th>Aksi</th>
            </tr>

            <?php
            include 'koneksi.php';
            $query = "SELECT * FROM tb_detail_transaksi";
            $result = mysqli_query($koneksi, $query);
            while ($data = mysqli_fetch_assoc($result)) {
            ?>
                <tr>
                    <td><?php echo $data['id']; ?></td>
                    <td><?php echo $data['id_transaksi']; ?></td>
                    <td><?php echo $data['id_paket']; ?></td>
                    <td><?php echo $data['qty']; ?></td>
                    <td><?php echo $data['keterangan']; ?></td>
                    <td>
                        <a href="editlaporan.php?id=<?php echo $data['id']; ?>">Edit</a> |
                        <a href="hapuslaporan.php?id=<?php echo $data['id']; ?>">Hapus</a>
                    </td>
                </tr>
            <?php
            }
            ?>
            </tbody>
        </table>
        <p>
            <a href="tambahlaporan.php" class="btn btn-primary">Tambah Laporan</a><br><br>
            <a href="index.php" class="btn btn-primary">Kembali</a>
        </p>
    </body>
</html>




