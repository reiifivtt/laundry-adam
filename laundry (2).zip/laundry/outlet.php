<?php
session_start();
if (!isset($_SESSION['login'])) {
    header("Location: login.php");
    exit;
}
?>

<html>
    <head>
        <title>Outlet</title>
        <link rel="stylesheet" href="css/table.css">
    </head>
    <body>
        <h1>Outlet</h1>
        <table>
            <tr>
                <th>ID</th>
                <th>Nama</th>
                <th>Alamat</th>
                <th>Telepon</th>
                <th>Aksi</th>
            </tr>

            <?php
            include 'koneksi.php';
            $query = "SELECT * FROM tb_outlet";
            $result = mysqli_query($koneksi, $query);
            while ($data = mysqli_fetch_assoc($result)) {
            ?>
                <tr>
                    <td><?php echo $data['id']; ?></td>
                    <td><?php echo $data['nama']; ?></td>
                    <td><?php echo $data['alamat']; ?></td>
                    <td><?php echo $data['tlp']; ?></td>
                    <td>
                        <a href="editoutlet.php?id=<?php echo $data['id']; ?>">Edit</a> |
                        <a href="hapusoutlet.php?id=<?php echo $data['id']; ?>">Hapus</a>
                    </td>
                </tr>
            <?php
            }
            ?>
        </table>
        <p>
            <a href="tambahoutlet.php" class="btn btn-primary">Tambah Outlet</a><br><br>
            <a href="index.php" class="btn btn-primary">Kembali</a>
        </p>
    </body>
</html>

