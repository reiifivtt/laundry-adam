<?php
session_start();
if (!isset($_SESSION['login'])) {
    header("Location: login.php");
    exit;
}

include 'koneksi.php';

if (isset($_POST['tambah'])) {
    $nama = mysqli_real_escape_string($koneksi, $_POST['nama']);
    $username = mysqli_real_escape_string($koneksi, $_POST['username']);
    $password = mysqli_real_escape_string($koneksi, $_POST['password']);
    $id_outlet = mysqli_real_escape_string($koneksi, $_POST['id_outlet']);
    $role = mysqli_real_escape_string($koneksi, $_POST['role']);

    $query = "SELECT MAX(id) as max_id FROM tb_user";
    $result = mysqli_query($koneksi, $query);
    $data = mysqli_fetch_assoc($result);
    $new_id = $data['max_id'] + 1;

    $query_insert = "INSERT INTO tb_user (id, nama, username, password, id_outlet, role) VALUES ('$new_id', '$nama', '$username', '$password', '$id_outlet', '$role')";
    
    if (mysqli_query($koneksi, $query_insert)) {
        header("Location: pengguna.php?status=success");
    } else {
        header("Location: tambahpengguna.php?status=error");
    }
}
?>
