<?php
session_start();
if (!isset($_SESSION['login'])) {
    header("Location: login.php");
    exit;
}

include 'koneksi.php';

$id = $_GET['id'];
$query = "SELECT * FROM tb_detail_transaksi WHERE id = '$id'";
$result = mysqli_query($koneksi, $query);
$data = mysqli_fetch_assoc($result);

if (isset($_POST['edit'])) {
    $id_transaksi = mysqli_real_escape_string($koneksi, $_POST['id_transaksi']);
    $id_paket = mysqli_real_escape_string($koneksi, $_POST['id_paket']);
    $qty = mysqli_real_escape_string($koneksi, $_POST['qty']);
    $keterangan = mysqli_real_escape_string($koneksi, $_POST['keterangan']);

    $query = "UPDATE tb_detail_transaksi SET id_transaksi = '$id_transaksi', id_paket = '$id_paket', qty = '$qty', keterangan = '$keterangan' WHERE id = '$id'";
    $result = mysqli_query($koneksi, $query);

    if ($result) {
        echo "<script>alert('Data laporan berhasil diupdate!');</script>";
        header("Location: laporan.php");
    } else {
        echo "<script>alert('Gagal update data laporan!');</script>";
    }
}
?>

<html>
    <head>
        <title>Edit Laporan</title>
        <link rel="stylesheet" href="css/style.css">
    </head>

    <body>
        <h1>Edit Laporan</h1>
        <form method="POST" action="" class="tambah-registrasi-form">
        <label for="id_transaksi">ID Transaksi:</label>
            <select name="id_transaksi" required>
                <?php
                include 'koneksi.php';
                $query = "SELECT id, kode_invoice FROM tb_transaksi";
                $result = mysqli_query($koneksi, $query);
                while ($transaksi = mysqli_fetch_assoc($result)) {
                    $selected = ($transaksi['id'] == $data['id_transaksi']) ? 'selected' : '';
                    echo "<option value='".$transaksi['id']."' $selected>".$transaksi['id']." | ".$transaksi['kode_invoice']."</option>";
                }
                ?>
            </select>

            <label for="id_paket">ID Paket:</label>
            <select name="id_paket" required>
                <?php
                include 'koneksi.php';
                $query = "SELECT id, nama_paket FROM tb_paket";
                $result = mysqli_query($koneksi, $query);
                while ($paket = mysqli_fetch_assoc($result)) {
                    $selected = ($paket['id'] == $data['id_paket']) ? 'selected' : '';
                    echo "<option value='".$paket['id']."' $selected>".$paket['id']." | ".$paket['nama_paket']."</option>";
                }
                ?>
            </select>

            <label for="qty">QTY:</label>
            <input type="number" name="qty" value="<?php echo $data['qty']; ?>" required>

            <label for="keterangan">Alamat:</label>
            <textarea name="keterangan" required><?php echo $data['keterangan']; ?></textarea>

            <div class="button-container">
                <button type="submit" name="edit">Edit</button>
                <button type="button" name="batal" onclick="window.history.back();">Batal</button>
            </div>
        </form>
    </body>
</html>