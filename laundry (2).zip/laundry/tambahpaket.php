<?php
session_start();
if (!isset($_SESSION['login'])) {
    header("Location: login.php");
    exit;
}
?>

<html>
    <head>
        <title>Tambah Paket</title>
        <link rel="stylesheet" href="css/style.css">
    </head>

    <body>
        <h1>Tambah Paket</h1>
        <form method="POST" action="prosestambahpaket.php">
            <label for="id_outlet">ID Outlet:</label>
            <select name="id_outlet" required>
                <?php
                include 'koneksi.php';
                $query = "SELECT id, nama FROM tb_outlet";
                $result = mysqli_query($koneksi, $query);
                while ($outlet = mysqli_fetch_assoc($result)) {
                    echo "<option value='".$outlet['id']."'>".$outlet['id']." | ".$outlet['nama']."</option>";
                }
                ?>
            </select>

            <label for="jenis">Jenis:</label>
            <select name="jenis" required>
                <option value="kiloan">Kiloan</option>
                <option value="selimut">Selimut</option>
                <option value="bed_cover">Bed Cover</option>
                <option value="kaos">Kaos</option>
                <option value="lain">Lain</option>
            </select>

            <label for="nama_paket">Nama Paket:</label>
            <input type="text" name="nama_paket" required>

            <label for="harga">Harga:</label>
            <input type="number" name="harga" required>

            <div class="button-container">
                <button type="submit" name="tambah">Tambah</button>
                <button type="button" name="batal" onclick="window.history.back();">Batal</button>
            </div>
        </form>
    </body>
</html>
