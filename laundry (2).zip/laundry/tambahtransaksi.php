<?php
session_start();
if (!isset($_SESSION['login'])) {
    header("Location: login.php");
    exit;
}
?>

<html>
    <head>
        <title>Tambah Transaksi</title>
        <link rel="stylesheet" href="css/style.css">
    </head>

    <body>
        <h1>Tambah Transaksi</h1>
        <form method="POST" action="prosestambahtransaksi.php">
            <label for="id_outlet">ID Outlet:</label>
            <select name="id_outlet" required>
                <?php
                include 'koneksi.php';
                $query = "SELECT id, nama FROM tb_outlet";
                $result = mysqli_query($koneksi, $query);
                while ($outlet = mysqli_fetch_assoc($result)) {
                    echo "<option value='".$outlet['id']."'>".$outlet['id']." | ".$outlet['nama']."</option>";
                }
                ?>
            </select>

            <label for="kode_invoice">Kode Invoice:</label>
            <input type="text" name="kode_invoice" required>

            <label for="id_member">ID Member:</label>
            <select name="id_member" required>
                <?php
                include 'koneksi.php';
                $query = "SELECT id, nama FROM tb_member";
                $result = mysqli_query($koneksi, $query);
                while ($member = mysqli_fetch_assoc($result)) {
                    echo "<option value='".$member['id']."'>".$member['id']." | ".$member['nama']."</option>";
                }
                ?>
            </select>     

            <label for="tgl">Tanggal:</label>
            <input type="datetime-local" name="tgl" required>

            <label for="batas_waktu">Batas Waktu:</label>
            <input type="datetime-local" name="batas_waktu" required>

            <label for="tgl_bayar">Tanggal Bayar:</label>
            <input type="datetime-local" name="tgl_bayar" required>

            <label for="biaya_tambahan">Biaya Tambahan:</label>
            <input type="number" name="biaya_tambahan" required>

            <label for="diskon">Diskon (%):</label>
            <input type="number" name="diskon" required>

            <label for="pajak">Pajak (%):</label>
            <input type="number" name="pajak" required>

            <label for="status">Status:</label>
            <select name="status" required>
                <option value="baru">Baru</option>
                <option value="proses">Proses</option>
                <option value="selesai">Selesai</option>
                <option value="diambil">Diambil</option>
            </select>

            <label for="dibayar">Dibayar:</label>
            <select name="dibayar" required>
                <option value="dibayar">Dibayar</option>
                <option value="belum_dibayar">Belum Dibayar</option>
            </select>

            <label for="id_user">ID User:</label>
            <select name="id_user" required>
                <?php
                include 'koneksi.php';
                $query = "SELECT id, nama FROM tb_user";
                $result = mysqli_query($koneksi, $query);
                while ($user = mysqli_fetch_assoc($result)) {
                    echo "<option value='".$user['id']."'>".$user['id']." | ".$user['nama']."</option>";
                }
                ?>
            </select>

            <div class="button-container">
                <button type="submit" name="tambah">Tambah</button>
                <button type="button" name="batal" onclick="window.history.back();">Batal</button>
            </div>
        </form>
    </body>
</html>
