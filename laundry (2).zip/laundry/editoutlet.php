<?php
session_start();
if (!isset($_SESSION['login'])) {
    header("Location: login.php");
    exit;
}

include 'koneksi.php';

$id = $_GET['id'];
$query = "SELECT * FROM tb_outlet WHERE id = '$id'";
$result = mysqli_query($koneksi, $query);
$data = mysqli_fetch_assoc($result);

if (isset($_POST['edit'])) {
    $nama = mysqli_real_escape_string($koneksi, $_POST['nama']);
    $alamat = mysqli_real_escape_string($koneksi, $_POST['alamat']);
    $tlp = mysqli_real_escape_string($koneksi, $_POST['tlp']);

    $query = "UPDATE tb_outlet SET nama = '$nama', alamat = '$alamat', tlp = '$tlp' WHERE id = '$id'";
    $result = mysqli_query($koneksi, $query);

    if ($result) {
        echo "<script>alert('Data outlet berhasil diupdate!');</script>";
        header("Location: outlet.php");
    } else {
        echo "<script>alert('Gagal update data outlet!');</script>";
    }
}
?>

<html>
    <head>
        <title>Edit Outlet</title>
        <link rel="stylesheet" href="css/style.css">
    </head>

    <body>
        <h1>Edit Outlet</h1>
        <form method="POST" action="" class="tambah-registrasi-form">
            <label for="nama">Nama:</label>
            <input type="text" name="nama" value="<?php echo $data['nama']; ?>" required>

            <label for="alamat">Alamat:</label>
            <textarea name="alamat" required><?php echo $data['alamat']; ?></textarea>

            <label for="tlp">No. Telepon:</label>
            <input type="tel" name="tlp" value="<?php echo $data['tlp']; ?>" required>

            <div class="button-container">
                <button type="submit" name="edit">Edit</button>
                <button type="button" name="batal" onclick="window.history.back();">Batal</button>
            </div>
        </form>
    </body>
</html>