<?php
session_start();
include 'koneksi.php';

if (isset($_POST['login'])) {
    $username = $_POST['username'];
    $password = $_POST['password'];

    // Perbaiki query agar aman dari SQL Injection
    $query = "SELECT * FROM tb_user WHERE username=? AND password=?";
    $stmt = mysqli_prepare($koneksi, $query);
    mysqli_stmt_bind_param($stmt, "ss", $username, $password);
    mysqli_stmt_execute($stmt);
    $result = mysqli_stmt_get_result($stmt);

    if (mysqli_num_rows($result) > 0) {
        $user = mysqli_fetch_assoc($result);
        $role = $user['role'];

        $_SESSION['login'] = true;
        $_SESSION['username'] = $username;
        $_SESSION['role'] = $role;

        // Mengalihkan ke index.php berdasarkan role
        header("Location: index.php");
        exit;
    } else {
        echo "Username atau password salah!";
    }
}
?>
