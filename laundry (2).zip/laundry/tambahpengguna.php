<?php
session_start();
if (!isset($_SESSION['login'])) {
    header("Location: login.php");
    exit;
}
?>

<html>
    <head>
        <title>Tambah Pengguna</title>
        <link rel="stylesheet" href="css/style.css">
    </head>

    <body>
        <h1>Tambah Pengguna</h1>
        <form method="POST" action="prosestambahpengguna.php">
            <label for="nama">Nama:</label>
            <input type="text" name="nama" required>

            <label for="username">Username:</label>
            <input type="text" name="username" required>

            <label for="password">Password:</label>
            <input type="password" name="password" required>

            <label for="id_outlet">ID Outlet:</label>
            <select name="id_outlet" required>
                <?php
                include 'koneksi.php';
                $query = "SELECT id, nama FROM tb_outlet";
                $result = mysqli_query($koneksi, $query);
                while ($outlet = mysqli_fetch_assoc($result)) {
                    echo "<option value='".$outlet['id']."'>".$outlet['id']." | ".$outlet['nama']."</option>";
                }
                ?>
            </select>

            <label for="role">Role:</label>
            <select name="role" required>
                <option value="admin">Admin</option>
                <option value="kasir">Kasir</option>
                <option value="owner">Owner</option>
            </select>

            <div class="button-container">
                <button type="submit" name="tambah">Tambah</button>
                <button type="button" name="batal" onclick="window.history.back();">Batal</button>
            </div>
        </form>
    </body>
</html>
