<?php
session_start();
if (!isset($_SESSION['login'])) {
    header("Location: login.php");
    exit;
}
?>

<html>
    <head>
        <title>Tambah Outlet</title>
        <link rel="stylesheet" href="css/style.css">
    </head>

    <body>
        <h1>Tambah Outlet</h1>
        <form method="POST" action="prosestambahoutlet.php">
            <label for="nama">Nama:</label>
            <input type="text" name="nama" required>

            <label for="alamat">Alamat:</label>
            <textarea name="alamat" required></textarea>

            <label for="tlp">Telepon:</label>
            <input type="tel" name="tlp" required>

            <div class="button-container">
                <button type="submit" name="tambah">Tambah</button>
                <button type="button" name="batal" onclick="window.history.back();">Batal</button>
            </div>
        </form>
    </body>
</html>