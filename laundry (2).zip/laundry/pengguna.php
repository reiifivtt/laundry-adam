<?php
session_start();
if (!isset($_SESSION['login'])) {
    header("Location: login.php");
    exit;
}
?>

<html>
    <head>
        <title>Pengguna</title>
        <link rel="stylesheet" href="css/table.css">
    </head>
    <body>
        <h1>Pengguna</h1>
        <table>
            <tr>
                <th>ID</th>
                <th>Nama</th>
                <th>Username</th>
                <th>Password</th>
                <th>ID Outlet</th>
                <th>Role</th>
                <th>Aksi</th>
            </tr>

            <?php
            include 'koneksi.php';
            $query = "SELECT * FROM tb_user";
            $result = mysqli_query($koneksi, $query);
            while ($data = mysqli_fetch_assoc($result)) {
            ?>
                <tr>
                    <td><?php echo $data['id']; ?></td>
                    <td><?php echo $data['nama']; ?></td>
                    <td><?php echo $data['username']; ?></td>
                    <td><?php echo $data['password']; ?></td>
                    <td><?php echo $data['id_outlet']; ?></td>
                    <td><?php echo $data['role']; ?></td>
                    <td>
                        <a href="editpengguna.php?id=<?php echo $data['id']; ?>">Edit</a> |
                        <a href="hapuspengguna.php?id=<?php echo $data['id']; ?>">Hapus</a>
                    </td>
                </tr>
            <?php
            }
            ?>
        </table>
        <p>
            <a href="tambahpengguna.php" class="btn btn-primary">Tambah Pengguna</a><br><br>
            <a href="index.php" class="btn btn-primary">Kembali</a>
        </p>
    </body>
</html>