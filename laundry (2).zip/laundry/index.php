<?php
session_start();
if (!isset($_SESSION['login'])) {
    header("Location: login.php");
    exit;
}

$role = $_SESSION['role'];

?>
<html>
    <head>
        <title><?php echo ucfirst($role); ?> Dashboard</title>
        <style>
            body {
                font-family: Arial, sans-serif;
                color: #003366;
                text-align: center;
                background-color: #F2F2F2;
                margin: 0;
                padding: 20px;
            }

            h1 {
                margin-bottom: 20px;
            }

            a {
                display: inline-block;
                margin: 10px;
                padding: 10px 20px;
                background-color: #003366;
                color: #FFFFFF;
                text-decoration: none;
                border-radius: 5px;
                transition: background-color 0.3s;
            }

            a:hover {
                background-color: #FFD700;
                color: #003366; 
            }

            h2 {
                margin-top: 20px;
                font-size: 1.5em;
                color: #003366;
            }
        </style>
    </head>

    <body>
        <?php if ($role === 'admin'): ?>
            <h1>Admin Dashboard</h1>
            <a href="registrasi.php">Registrasi Pelanggan</a>
            <a href="outlet.php">CRUD Outlet</a>
            <a href="paket.php">CRUD Produk/Paket Cucian</a>
            <a href="pengguna.php">CRUD Pengguna</a>
            <a href="transaksi.php">Entri Transaksi</a>
            <a href="laporan.php">Generate Laporan</a>
            <h2>Selamat datang, Admin!</h2>

        <?php elseif ($role === 'kasir'): ?>
            <h1>Kasir Dashboard</h1>
            <a href="registrasi.php">Registrasi Pelanggan</a>
            <a href="transaksi.php">Entri Transaksi</a>
            <a href="laporan.php">Generate Laporan</a>
            <h2>Selamat datang, Kasir!</h2>

        <?php elseif ($role === 'owner'): ?>
            <h1>Owner Dashboard</h1>
            <a href="laporan.php">Generate Laporan</a>
            <h2>Selamat datang, Owner!</h2>
        <?php else: ?>
            <h1>Tidak memiliki akses</h1>
            <p>Kamu tidak memiliki akses di halaman ini</p>
        <?php endif; ?>

        <a href="logout.php">Logout</a>
    </body>
</html>
