<?php
session_start();
if (!isset($_SESSION['login'])) {
    header("Location: login.php");
    exit;
}
?>

<html>
    <head>
        <title>Paket</title>
        <link rel="stylesheet" href="css/table.css">
    </head>
    <body>
        <h1>Paket</h1>
        <table>
            <tr>
                <th>ID</th>
                <th>ID Outlet</th>
                <th>Jenis</th>
                <th>Nama Paket</th>
                <th>Harga</th>
                <th>Aksi</th>
            </tr>

            <?php
            include 'koneksi.php';
            $query = "SELECT * FROM tb_paket";
            $result = mysqli_query($koneksi, $query);
            while ($data = mysqli_fetch_assoc($result)) {
            ?>
                <tr>
                    <td><?php echo $data['id']; ?></td>
                    <td><?php echo $data['id_outlet']; ?></td>
                    <td><?php echo $data['jenis']; ?></td>
                    <td><?php echo $data['nama_paket']; ?></td>
                    <td><?php echo $data['harga']; ?></td>
                    <td>
                        <a href="editpaket.php?id=<?php echo $data['id']; ?>">Edit</a> |
                        <a href="hapuspaket.php?id=<?php echo $data['id']; ?>">Hapus</a>
                    </td>
                </tr>
            <?php
            }
            ?>
        </table>
        <p>
            <a href="tambahpaket.php" class="btn btn-primary">Tambah Paket</a><br><br>
            <a href="index.php" class="btn btn-primary">Kembali</a>
        </p>
    </body>
</html>