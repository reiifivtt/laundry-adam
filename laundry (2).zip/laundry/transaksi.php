<?php
session_start();
if (!isset($_SESSION['login'])) {
    header("Location: login.php");
    exit;
}
?>

<html>
    <head>
        <title>Transaksi</title>
        <link rel="stylesheet" href="css/table.css">
    </head>
    <body>
        <h1>Transaksi</h1>
        <table>
            <tr>
                <th>ID</th>
                <th>ID Outlet</th>
                <th>Kode Invoice</th>
                <th>ID Member</th>
                <th>Tanggal</th>
                <th>Batas Waktu</th>
                <th>Tanggal Bayar</th>
                <th>Biaya Tambahan</th>
                <th>Diskon (%)</th>
                <th>Pajak (%)</th>
                <th>Status</th>
                <th>Dibayar</th>
                <th>ID User</th>
                <th>Aksi</th>
            </tr>

            <?php
            include 'koneksi.php';
            $query = "SELECT * FROM tb_transaksi";
            $result = mysqli_query($koneksi, $query);
            while ($data = mysqli_fetch_assoc($result)) {
            ?>
                <tr>
                    <td><?php echo $data['id']; ?></td>
                    <td><?php echo $data['id_outlet']; ?></td>
                    <td><?php echo $data['kode_invoice']; ?></td>
                    <td><?php echo $data['id_member']; ?></td>
                    <td><?php echo $data['tgl']; ?></td>
                    <td><?php echo $data['batas_waktu']; ?></td>
                    <td><?php echo $data['tgl_bayar']; ?></td>
                    <td><?php echo $data['biaya_tambahan']; ?></td>
                    <td><?php echo $data['diskon']; ?>%</td>
                    <td><?php echo $data['pajak']; ?>%</td>
                    <td><?php echo $data['status']; ?></td>
                    <td><?php echo $data['dibayar']; ?></td>
                    <td><?php echo $data['id_user']; ?></td>
                    <td>
                        <a href="edittransaksi.php?id=<?php echo $data['id']; ?>">Edit</a> |
                        <a href="hapustransaksi.php?id=<?php echo $data['id']; ?>">Hapus</a>
                    </td>
                </tr>
            <?php
            }
            ?>
        </table>
        <p>
            <a href="tambahtransaksi.php" class="btn btn-primary">Tambah Transaksi</a><br><br>
            <a href="index.php" class="btn btn-primary">Kembali</a>
        </p>
    </body>
</html>
