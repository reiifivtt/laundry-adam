<?php
session_start();
if (!isset($_SESSION['login'])) {
    header("Location: login.php");
    exit;
}

include 'koneksi.php';

if (isset($_POST['tambah'])) {
    $id_outlet = mysqli_real_escape_string($koneksi, $_POST['id_outlet']);
    $kode_invoice = mysqli_real_escape_string($koneksi, $_POST['kode_invoice']);
    $id_member = mysqli_real_escape_string($koneksi, $_POST['id_member']);
    $tgl = mysqli_real_escape_string($koneksi, $_POST['tgl']);
    $batas_waktu = mysqli_real_escape_string($koneksi, $_POST['batas_waktu']);
    $tgl_bayar = mysqli_real_escape_string($koneksi, $_POST['tgl_bayar']);
    $biaya_tambahan = mysqli_real_escape_string($koneksi, $_POST['biaya_tambahan']);
    $diskon = intval(mysqli_real_escape_string($koneksi, $_POST['diskon']));
    $pajak = intval(mysqli_real_escape_string($koneksi, $_POST['pajak']));
    $status = mysqli_real_escape_string($koneksi, $_POST['status']);
    $dibayar = mysqli_real_escape_string($koneksi, $_POST['dibayar']);
    $id_user = mysqli_real_escape_string($koneksi, $_POST['id_user']);

    $query = "SELECT MAX(id) as max_id FROM tb_transaksi";
    $result = mysqli_query($koneksi, $query);
    $data = mysqli_fetch_assoc($result);
    $new_id = $data['max_id'] + 1;

    $query_insert = "INSERT INTO tb_transaksi (id, id_outlet, kode_invoice, id_member, tgl, batas_waktu, tgl_bayar, biaya_tambahan, diskon, pajak, status, dibayar, id_user) 
                     VALUES ('$new_id', '$id_outlet', '$kode_invoice', '$id_member', '$tgl', '$batas_waktu', '$tgl_bayar', '$biaya_tambahan', '$diskon', '$pajak', '$status', '$dibayar', '$id_user')";
    
    if (mysqli_query($koneksi, $query_insert)) {
        header("Location: transaksi.php?status=success");
    } else {
        header("Location: tambahtransaksi.php?status=error");
    }
}
?>
