<?php
session_start();
if (!isset($_SESSION['login'])) {
    header("Location: login.php");
    exit;
}

include 'koneksi.php';

if (isset($_POST['tambah'])) {
    $nama = mysqli_real_escape_string($koneksi, $_POST['nama']);
    $alamat = mysqli_real_escape_string($koneksi, $_POST['alamat']);
    $jenis_kelamin = mysqli_real_escape_string($koneksi, $_POST['jenis_kelamin']);
    $tlp = mysqli_real_escape_string($koneksi, $_POST['tlp']);

    $query = "SELECT MAX(id) as max_id FROM tb_member";
    $result = mysqli_query($koneksi, $query);
    $data = mysqli_fetch_assoc($result);
    $new_id = $data['max_id'] + 1;

    $query_insert = "INSERT INTO tb_member (id, nama, alamat, jenis_kelamin, tlp) VALUES ('$new_id', '$nama', '$alamat', '$jenis_kelamin', '$tlp')";
    
    if (mysqli_query($koneksi, $query_insert)) {
        header("Location: registrasi.php?status=success");
    } else {
        header("Location: tambahregistrasi.php?status=error");
    }
}
?>
