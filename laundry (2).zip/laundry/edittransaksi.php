<?php
session_start();
if (!isset($_SESSION['login'])) {
    header("Location: login.php");
    exit;
}

include 'koneksi.php';

$id = $_GET['id'];
$query = "SELECT * FROM tb_transaksi WHERE id = '$id'";
$result = mysqli_query($koneksi, $query);
$data = mysqli_fetch_assoc($result);

if (isset($_POST['edit'])) {
    $id_outlet = mysqli_real_escape_string($koneksi, $_POST['id_outlet']);
    $kode_invoice = mysqli_real_escape_string($koneksi, $_POST['kode_invoice']);
    $id_member = mysqli_real_escape_string($koneksi, $_POST['id_member']);
    $tgl = mysqli_real_escape_string($koneksi, $_POST['tgl']);
    $batas_waktu = mysqli_real_escape_string($koneksi, $_POST['batas_waktu']);
    $tgl_bayar = mysqli_real_escape_string($koneksi, $_POST['tgl_bayar']);
    $biaya_tambahan = mysqli_real_escape_string($koneksi, $_POST['biaya_tambahan']);
    $diskon = mysqli_real_escape_string($koneksi, $_POST['diskon']);
    $pajak = mysqli_real_escape_string($koneksi, $_POST['pajak']);
    $status = mysqli_real_escape_string($koneksi, $_POST['status']);
    $dibayar = mysqli_real_escape_string($koneksi, $_POST['dibayar']);
    $id_user = mysqli_real_escape_string($koneksi, $_POST['id_user']);

    $query = "UPDATE tb_transaksi SET id_outlet = '$id_outlet', kode_invoice = '$kode_invoice', id_member = '$id_member', tgl = '$tgl', batas_waktu = '$batas_waktu', 
    tgl_bayar = '$tgl_bayar', biaya_tambahan = '$biaya_tambahan', diskon = '$diskon', pajak = '$pajak', status = '$status', dibayar = '$dibayar', id_user = '$id_user' WHERE id = '$id'";
    
    $result = mysqli_query($koneksi, $query);

    if ($result) {
        echo "<script>alert('Data transaksi berhasil diupdate!');</script>";
        header("Location: transaksi.php");
        exit;
    } else {
        echo "<script>alert('Gagal update data transaksi!');</script>";
    }
}

?>

<html>
    <head>
        <title>Edit Transaksi</title>
        <link rel="stylesheet" href="css/style.css">
    </head>

    <body>
        <h1>Edit Transaksi</h1>
        <form method="POST" action="" class="tambah-transaksi-form">
            <label for="id_outlet">ID Outlet:</label>
            <select name="id_outlet" required>
                <?php
                $outlet_query = "SELECT id, nama FROM tb_outlet";
                $outlet_result = mysqli_query($koneksi, $outlet_query);
                while ($outlet = mysqli_fetch_assoc($outlet_result)) {
                    $selected = ($outlet['id'] == $data['id_outlet']) ? 'selected' : '';
                    echo "<option value='".$outlet['id']."' $selected>".$outlet['id']." | ".$outlet['nama']."</option>";
                }
                ?>
            </select>

            <label for="kode_invoice">Kode Invoice:</label>
            <input type="text" name="kode_invoice" value="<?php echo $data['kode_invoice']; ?>" required>

            <label for="id_member">ID Member:</label>
            <select name="id_member" required>
                <?php
                $member_query = "SELECT id, nama FROM tb_member";
                $member_result = mysqli_query($koneksi, $member_query);
                while ($member = mysqli_fetch_assoc($member_result)) {
                    $selected = ($member['id'] == $data['id_member']) ? 'selected' : '';
                    echo "<option value='".$member['id']."' $selected>".$member['id']." | ".$member['nama']."</option>";
                }
                ?>
            </select>

            <label for="tgl">Tanggal:</label>
            <input type="datetime-local" name="tgl" value="<?php echo $data['tgl']; ?>" required>

            <label for="batas_waktu">Batas Waktu:</label>
            <input type="datetime-local" name="batas_waktu" value="<?php echo $data['batas_waktu']; ?>" required>

            <label for="tgl_bayar">Tanggal Bayar:</label>
            <input type="datetime-local" name="tgl_bayar" value="<?php echo $data['tgl_bayar']; ?>" required>

            <label for="biaya_tambahan">Biaya Tambahan:</label>
            <input type="number" name="biaya_tambahan" value="<?php echo $data['biaya_tambahan']; ?>" required>

            <label for="diskon">Diskon (%):</label>
            <input type="number" name="diskon" value="<?php echo $data['diskon']; ?>" required>

            <label for="pajak">Pajak (%):</label>
            <input type="number" name="pajak" value="<?php echo $data['pajak']; ?>" required>

            <label for="status">Status:</label>
            <select name="status" required>
                <option value="<?php echo $data['status']; ?>"><?php echo $data['status']; ?></option>
                <option value="baru">Baru</option>
                <option value="proses">Proses</option>
                <option value="selesai">Selesai</option>
                <option value="diambil">Diambil</option>
            </select>

            <label for="dibayar">Dibayar:</label>
            <select name="dibayar" required>
                <option value="<?php echo $data['dibayar']; ?>"><?php echo $data['dibayar']; ?></option>
                <option value="dibayar">Dibayar</option>
                <option value="belum_dibayar">Belum Dibayar</option>
            </select>

            <label for="id_user">ID User:</label>
            <select name="id_user" required>
                <?php
                $user_query = "SELECT id, nama FROM tb_user";
                $user_result = mysqli_query($koneksi, $user_query);
                while ($user = mysqli_fetch_assoc($user_result)) {
                    $selected = ($user['id'] == $data['id_user']) ? 'selected' : '';
                    echo "<option value='".$user['id']."' $selected>".$user['id']." | ".$user['nama']."</option>";
                }
                ?>
            </select>

            <div class="button-container">
                <button type="submit" name="edit">Edit</button>
                <button type="button" name="batal" onclick="window.history.back();">Batal</button>
            </div>
        </form>
    </body>
</html>

