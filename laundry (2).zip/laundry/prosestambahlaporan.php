<?php
session_start();
if (!isset($_SESSION['login'])) {
    header("Location: login.php");
    exit;
}

include 'koneksi.php';

if (isset($_POST['tambah'])) {
    $id_transaksi = mysqli_real_escape_string($koneksi, $_POST['id_transaksi']);
    $id_paket = mysqli_real_escape_string($koneksi, $_POST['id_paket']);
    $qty = mysqli_real_escape_string($koneksi, $_POST['qty']);
    $keterangan = mysqli_real_escape_string($koneksi, $_POST['keterangan']);

    $query = "SELECT MAX(id) as max_id FROM tb_detail_transaksi";
    $result = mysqli_query($koneksi, $query);
    $data = mysqli_fetch_assoc($result);
    $new_id = $data['max_id'] + 1;

    $query_insert = "INSERT INTO tb_detail_transaksi (id, id_transaksi, id_paket, qty, keterangan) VALUES ('$new_id', '$id_transaksi', '$id_paket', '$qty', '$keterangan')";
    
    if (mysqli_query($koneksi, $query_insert)) {
        header("Location: laporan.php?status=success");
    } else {
        header("Location: tambahlaporan.php?status=error");
    }
}
?>
